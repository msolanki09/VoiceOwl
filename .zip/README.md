# VoiceOwl Transcription API

A Node.js application that downloads audio files from URLs and generates transcriptions, built with Express, TypeScript, and MongoDB.

## Requirements

- Node.js (v14+)
- npm

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Create `.env` file:
   ```
   PORT=3000
   NODE_ENV=development
   RETRY_ATTEMPTS=3
   RETRY_DELAY=1000
   ```

3. Build and start:
   ```bash
   npm run build
   npm run dev
   ```

4. Open http://localhost:3000

## API Endpoints

### POST /transcription
Creates a transcription from audio URL.

Request:
```json
{
  "audioUrl": "https://example.com/audio.mp3"
}
```

Response:
```json
{
  "_id": "507f1f77bcf86cd799439011",
  "originalUrl": "https://example.com/audio.mp3",
  "audioFileName": "audio_123456789.mp3",
  "audioFileUrl": "/audio/audio_123456789.mp3",
  "transcription": "transcribed text",
  "createdAt": "2025-01-01T10:00:00.000Z"
}
```

### GET /transcriptions
Returns all transcriptions.

### GET /audio/:filename
Serves audio files.

### GET /
Web interface for testing.

## Project Structure

```
src/
├── controllers/     # Request handlers
├── models/         # Database models
├── routes/         # Route definitions
├── services/       # Business logic
└── server.ts       # Main app
views/
└── index.ejs       # Frontend
audio_files/        # Downloaded audio files
```

## How it works

1. User submits audio URL
2. System downloads audio file to local storage
3. Generates transcription text
4. Saves data to MongoDB
5. Returns transcription with file reference

## Database

Uses MongoMemoryServer for development. Data includes:
- Original URL
- Local file path
- Transcription text
- Timestamp

## Features

- Downloads audio from URLs
- Supports Google Drive links
- Stores files locally
- Web interface for testing
- RESTful API endpoints
- Error handling and retries