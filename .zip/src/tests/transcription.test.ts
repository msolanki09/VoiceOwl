import { processTranscription } from '../services/transcriptionService';
import { connectDatabase, disconnectDatabase } from '../services/database';

describe('Transcription Service', () => {
  beforeAll(async () => {
    process.env.MONGODB_URI = 'mongodb://localhost:27017/voiceowl_test';
    await connectDatabase();
  });

  afterAll(async () => {
    await disconnectDatabase();
  });

  test('should process transcription successfully', async () => {
    const testUrl = 'https://example.com/test-audio.mp3';
    
    const result = await processTranscription(testUrl);
    
    expect(result).toBeDefined();
    expect(result._id).toBeDefined();
    expect(result.audioUrl).toBe(testUrl);
    expect(result.transcription).toContain('mock transcription');
    expect(result.createdAt).toBeInstanceOf(Date);
  });

  test('should handle invalid URL gracefully', async () => {
    const invalidUrl = 'not-a-valid-url';
    
    try {
      await processTranscription(invalidUrl);
    } catch (error) {
      expect(error).toBeDefined();
    }
  });
});