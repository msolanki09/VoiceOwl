import { Router } from 'express';
import { createTranscription, getTranscriptions, renderHomePage, serveAudioFile } from '../controllers/transcriptionController';

const router = Router();

router.get('/', renderHomePage);
router.post('/transcription', createTranscription);
router.get('/transcriptions', getTranscriptions);
router.get('/audio/:filename', serveAudioFile);

export default router;