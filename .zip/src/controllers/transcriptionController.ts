import { Request, Response } from 'express';
import { processTranscription, getAllTranscriptions } from '../services/transcriptionService';
import path from 'path';
import fs from 'fs';

export const createTranscription = async (req: Request, res: Response) => {
  try {
    const { audioUrl } = req.body;
    
    if (!audioUrl) {
      return res.status(400).json({ 
        error: 'audioUrl is required' 
      });
    }
    
    if (!isValidUrl(audioUrl)) {
      return res.status(400).json({ 
        error: 'Invalid URL format' 
      });
    }
    
    const result = await processTranscription(audioUrl);
    
    res.status(201).json({
      _id: result._id,
      originalUrl: result.originalUrl,
      audioFileName: result.audioFileName,
      audioFileUrl: `/audio/${result.audioFileName}`,
      transcription: result.transcription,
      createdAt: result.createdAt
    });
  } catch (error) {
    console.error('Controller error:', error);
    res.status(500).json({ 
      error: 'Internal server error during transcription processing' 
    });
  }
};

export const getTranscriptions = async (req: Request, res: Response) => {
  try {
    const transcriptions = await getAllTranscriptions();
    
    // Add audio file URL to each transcription
    const transcriptionsWithUrls = transcriptions.map(transcription => ({
      ...transcription.toObject(),
      audioFileUrl: `/audio/${transcription.audioFileName}`
    }));
    
    res.json(transcriptionsWithUrls);
  } catch (error) {
    console.error('Controller error:', error);
    res.status(500).json({ 
      error: 'Internal server error while fetching transcriptions' 
    });
  }
};

export const renderHomePage = async (req: Request, res: Response) => {
  try {
    const transcriptions = await getAllTranscriptions();
    
    // Add audio file URL to each transcription for the template
    const transcriptionsWithUrls = transcriptions.map(transcription => ({
      ...transcription.toObject(),
      audioFileUrl: `/audio/${transcription.audioFileName}`
    }));
    
    res.render('index', { transcriptions: transcriptionsWithUrls });
  } catch (error) {
    console.error('Render error:', error);
    res.render('index', { transcriptions: [] });
  }
};

export const serveAudioFile = async (req: Request, res: Response) => {
  try {
    const { filename } = req.params;
    const audioFilePath = path.join(__dirname, '../../audio_files', filename);
    
    if (!fs.existsSync(audioFilePath)) {
      return res.status(404).json({ error: 'Audio file not found' });
    }
    
    const stats = fs.statSync(audioFilePath);
    const fileExtension = path.extname(filename).toLowerCase();
    
    let contentType = 'audio/mpeg';
    switch (fileExtension) {
      case '.mp3':
        contentType = 'audio/mpeg';
        break;
      case '.wav':
        contentType = 'audio/wav';
        break;
      case '.ogg':
        contentType = 'audio/ogg';
        break;
      case '.m4a':
        contentType = 'audio/mp4';
        break;
    }
    
    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Length', stats.size);
    res.setHeader('Content-Disposition', `inline; filename="${filename}"`);
    
    const fileStream = fs.createReadStream(audioFilePath);
    fileStream.pipe(res);
  } catch (error) {
    console.error('Audio serve error:', error);
    res.status(500).json({ error: 'Error serving audio file' });
  }
};

const isValidUrl = (string: string) => {
  try {
    new URL(string);
    return true;
  } catch (_) {
    return false;
  }
};