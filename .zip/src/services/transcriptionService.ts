import { Transcription } from '../models/Transcription';
import { downloadAudioFile, transcribeAudio } from './audioService';

export const processTranscription = async (audioUrl: string) => {
  try {
    const retryAttempts = parseInt(process.env.RETRY_ATTEMPTS || '3');
    
    const audioFileInfo = await downloadAudioFile(audioUrl, retryAttempts);
    
    if (!audioFileInfo) {
      throw new Error('Failed to download audio file after all retry attempts');
    }
    
    const transcriptionText = await transcribeAudio(audioFileInfo.filePath);
    
    const transcription = new Transcription({
      originalUrl: audioUrl,
      audioFilePath: audioFileInfo.filePath,
      audioFileName: audioFileInfo.fileName,
      transcription: transcriptionText,
      createdAt: new Date()
    });
    
    const savedTranscription = await transcription.save();
    return savedTranscription;
  } catch (error) {
    console.error('Transcription processing error:', error);
    throw error;
  }
};

export const getAllTranscriptions = async () => {
  try {
    const transcriptions = await Transcription.find().sort({ createdAt: -1 });
    return transcriptions;
  } catch (error) {
    console.error('Error fetching transcriptions:', error);
    throw error;
  }
};