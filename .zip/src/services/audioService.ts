import axios from 'axios';
import fs from 'fs';
import path from 'path';

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

interface AudioFileInfo {
  filePath: string;
  fileName: string;
  fileSize: number;
}

export const downloadAudioFile = async (url: string, retryAttempts = 3): Promise<AudioFileInfo> => {
  const directUrl = convertGoogleDriveUrl(url);
  
  for (let attempt = 1; attempt <= retryAttempts; attempt++) {
    try {
      
      const response = await axios({
        method: 'GET',
        url: directUrl,
        responseType: 'stream',
        timeout: 60000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      });
      
      const fileName = `audio_${Date.now()}.${getFileExtension(url)}`;
      const audioDir = path.join(__dirname, '../../audio_files');
      
      if (!fs.existsSync(audioDir)) {
        fs.mkdirSync(audioDir, { recursive: true });
      }
      
      const filePath = path.join(audioDir, fileName);
      const writer = fs.createWriteStream(filePath);
      response.data.pipe(writer);
      
      return new Promise<AudioFileInfo>((resolve, reject) => {
        writer.on('finish', () => {
          const stats = fs.statSync(filePath);
          resolve({
            filePath: filePath,
            fileName: fileName,
            fileSize: stats.size
          });
        });
        writer.on('error', reject);
      });
      
    } catch (error) {
      
      if (attempt === retryAttempts) {
        throw new Error(`Failed to download audio after ${retryAttempts} attempts`);
      }
      
      const delay = parseInt(process.env.RETRY_DELAY || '1000') * attempt;
      await sleep(delay);
    }
  }
  
  throw new Error('Download failed after all attempts');
};

export const transcribeAudio = async (filePath: string): Promise<string> => {
  await sleep(500);
  return "transcribed text";
};

const convertGoogleDriveUrl = (url: string): string => {
  const regex = /\/file\/d\/([a-zA-Z0-9-_]+)/;
  const match = url.match(regex);
  
  if (match) {
    const fileId = match[1];
    return `https://drive.google.com/uc?export=download&id=${fileId}`;
  }
  
  return url;
};

const getFileExtension = (url: string): string => {
  try {
    const urlPath = new URL(url).pathname;
    const extension = path.extname(urlPath).slice(1);
    return extension || 'mp3';
  } catch {
    return 'mp3';
  }
};